#!/usr/bin/env python3
"""
Evaluation harness for the Intelligent Digital Forensic AI Assistant.

Run from anywhere; point --repo at the project root (the folder that contains `backend/`).

  python run_eval.py --repo /path/to/Intelligent-Digital-Forensic-AI-Assistant --embedder real --llm
  python run_eval.py --repo ...  --embedder none        # exact-term retriever only, no models needed

--embedder real   uses the project's own all-MiniLM-L6-v2 loader (needs torch + sentence-transformers
                  and the model files available locally). Produces dense, exact-term and hybrid results.
--embedder none   no embedding model. Vectors are a constant placeholder and ONLY the project's
                  exact-term retriever (`lexical_search`) is evaluated. Dense/hybrid are not run.
--embedder stub   deterministic hashing embedder, for testing the harness plumbing ONLY. Its numbers
                  are meaningless as a measure of the real system and are labelled STUB.
--llm             also calls the project's `run_rag_query` (needs `ollama serve` + the model pulled);
                  records answers, latency, whether the model was consulted, and writes a claim-judging sheet.

What is indexed: the project's own `chunk_text` (700 chars, 120 overlap = ingestion_modes defaults) and the
project's own `store_chunks` into an isolated temporary Qdrant directory, one collection per case.
Nothing in the real data/ folder is touched.

Relevance label: a retrieved chunk is relevant to a query iff it contains the query's gold span
(whitespace-normalised, case-insensitive). Exactly one gold passage per answerable query.
Recall@k = (# queries with a relevant chunk in the top k) / (# answerable queries).
MRR = mean over queries of 1/rank of the first relevant chunk (0 if none in the list).
"""
import argparse, csv, hashlib, json, math, os, platform, re, statistics, sys, tempfile, time, uuid

HERE = os.path.dirname(os.path.abspath(__file__))
KS = (1, 3, 5, 10, 14)          # 14 = production RETRIEVAL_TOP_K
norm = lambda s: re.sub(r"\s+", " ", s or "").strip().lower()


def stub_vec(text, dim=384):
    v = [0.0] * dim
    for tok in re.findall(r"[a-z0-9]+", text.lower()):
        h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
        v[h % dim] += 1.0 if (h >> 8) % 2 else -1.0
    n = math.sqrt(sum(x * x for x in v)) or 1.0
    return [x / n for x in v]


def machine_info():
    info = {"python": sys.version.split()[0], "platform": platform.platform(),
            "processor": platform.processor() or platform.machine(), "cpu_count": os.cpu_count()}
    try:
        import psutil
        info["ram_gb"] = round(psutil.virtual_memory().total / 2**30, 1)
    except Exception:
        info["ram_gb"] = None
    try:
        import torch
        info["torch"] = torch.__version__
        info["cuda"] = bool(torch.cuda.is_available())
        if info["cuda"]:
            p = torch.cuda.get_device_properties(0)
            info["gpu"] = p.name; info["gpu_mem_gb"] = round(p.total_memory / 2**30, 1)
    except Exception:
        info["torch"] = None
    return info


def rank_of(hits, spans):
    """1-based rank of the first chunk containing any of `spans` (a str or list), else None."""
    spans = [norm(x) for x in ([spans] if isinstance(spans, str) else spans)]
    for i, h in enumerate(hits, 1):
        t = norm(h.get("text", ""))
        if any(s in t for s in spans):
            return i
    return None


def summarise(ranks):
    n = len(ranks)
    out = {"n": n}
    for k in KS:
        out[f"recall@{k}"] = {"hits": sum(1 for r in ranks if r and r <= k), "of": n}
    out["mrr"] = round(sum((1.0 / r) if r else 0.0 for r in ranks) / n, 4) if n else None
    return out


def timed(fn, reps=3):
    ms, res = [], None
    for _ in range(reps):
        t = time.perf_counter(); res = fn(); ms.append((time.perf_counter() - t) * 1000)
    return res, round(statistics.median(ms), 2)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--embedder", choices=["real", "none", "stub"], default="real")
    ap.add_argument("--llm", action="store_true")
    ap.add_argument("--out", default=os.path.join(HERE, "results"))
    a = ap.parse_args()

    sys.path.insert(0, os.path.abspath(a.repo))
    root = tempfile.mkdtemp(prefix="idfa_eval_")
    os.environ.update({"DATABASE_URL": "sqlite:///" + os.path.join(root, "eval.db").replace("\\", "/"),
                       "CASES_DIR": os.path.join(root, "cases"),
                       "QDRANT_DIR": os.path.join(root, "qdrant"), "DEBUG": "False"})
    if a.embedder in ("none", "stub"):
        # device_resolver imports torch at module load, but torch is only *used* when the real embedder
        # is constructed, which these modes bypass. A placeholder module lets the project's retrieval
        # code import on a machine without PyTorch. Not used with --embedder real.
        import types
        if "torch" not in sys.modules:
            try:
                import torch  # noqa: F401
            except ImportError:
                sys.modules["torch"] = types.ModuleType("torch")
    from backend.modules import vector_store as vs, rag_engine as rag
    from backend.modules.text_parser import chunk_text
    from backend.modules.ingestion_modes import CHUNK_SIZE, CHUNK_OVERLAP

    if a.embedder in ("none", "stub"):
        const = [1.0] + [0.0] * 383
        vs.describe_embedder = lambda: {"embedder_id": vs.EMBEDDER_ID, "vector_size": 384, "max_seq_length": 256}
        vs.get_ollama_embeddings = (lambda texts: [stub_vec(t) for t in texts]) if a.embedder == "stub" \
            else (lambda texts: [const for _ in texts])

    Q = json.load(open(os.path.join(HERE, "queries.json"), encoding="utf-8"))
    cases = {}
    for label in ("A", "B"):
        cid = str(uuid.uuid4()); qp = vs.case_qdrant_path(cid)
        files = {}
        d = os.path.join(HERE, "corpus", f"case_{label}")
        n_chunks = 0
        for fn in sorted(os.listdir(d)):
            text = open(os.path.join(d, fn), encoding="utf-8").read()
            chunks = chunk_text(text, chunk_size=CHUNK_SIZE, overlap=CHUNK_OVERLAP)
            vs.store_chunks(chunks=chunks, source_filename=fn, evidence_id=str(uuid.uuid4()),
                            case_id=cid, qdrant_path=qp,
                            chunking={"chunk_size": CHUNK_SIZE, "chunk_overlap": CHUNK_OVERLAP})
            files[fn] = len(chunks); n_chunks += len(chunks)
        cases[label] = {"case_id": cid, "qpath": qp, "files": files, "chunks": n_chunks}
    A, B = cases["A"], cases["B"]

    rep = {"embedder_mode": a.embedder, "machine": machine_info(), "chunk_size": CHUNK_SIZE,
           "chunk_overlap": CHUNK_OVERLAP, "retrieval_top_k_production": rag.RETRIEVAL_TOP_K,
           "case_A": {"files": len(A["files"]), "chunks": A["chunks"]},
           "case_B": {"files": len(B["files"]), "chunks": B["chunks"]},
           "n_answerable": len(Q["answerable"]), "n_unanswerable": len(Q["unanswerable"]),
           "n_cross_case": len(Q["cross_case"])}
    if a.embedder == "stub":
        rep["WARNING"] = "STUB embedder: dense/hybrid numbers are a plumbing test, NOT results."
    if a.embedder == "real":
        rep["embedder"] = vs.describe_embedder()

    retrievers = {"exact_term": lambda q: vs.lexical_search(q, A["case_id"], A["qpath"], limit=rag.RETRIEVAL_TOP_K)}
    if a.embedder in ("real", "stub"):
        retrievers["dense"] = lambda q: vs.search_chunks(q, A["case_id"], A["qpath"], top_k=rag.RETRIEVAL_TOP_K)
        retrievers["hybrid_rrf"] = lambda q: rag.retrieve(q, A["case_id"], A["qpath"], top_k=rag.RETRIEVAL_TOP_K)

    rows, per = [], {r: {"all": [], "identifier": [], "semantic": []} for r in retrievers}
    per_strict = {r: [] for r in retrievers}   # strict = gold span only; lenient (default) = gold or alt span
    lat = {r: [] for r in retrievers}
    for item in Q["answerable"]:
        row = {"id": item["id"], "kind": item["kind"], "query": item["query"], "gold_file": item["gold_file"]}
        for name, fn in retrievers.items():
            hits, ms = timed(lambda: fn(item["query"]))
            rk = rank_of(hits, [item["gold_span"]] + item.get("alt_spans", []))
            rk_strict = rank_of(hits, item["gold_span"])
            row[f"{name}_rank_strict"] = rk_strict; per_strict[name].append(rk_strict)
            row[f"{name}_rank"] = rk; row[f"{name}_top1_file"] = hits[0]["source"] if hits else None
            row[f"{name}_n"] = len(hits); row[f"{name}_ms"] = ms
            per[name]["all"].append(rk); per[name][item["kind"]].append(rk); lat[name].append(ms)
        rows.append(row)
    rep["retrieval"] = {n: {g: summarise(r) for g, r in per[n].items()} for n in retrievers}
    rep["retrieval_strict_gold_only"] = {n: summarise(per_strict[n]) for n in retrievers}
    rep["retrieval_latency_ms_median_of_queries"] = {n: round(statistics.median(v), 2) for n, v in lat.items()}

    # --- cross-case probes: case-B marker strings queried against case A (and A markers against B)
    leaks, xrows = 0, []
    for x in Q["cross_case"]:
        res = {}
        for name, fn in retrievers.items():
            hits = fn(x["query"])
            bad = [h for h in hits if h["source"] in B["files"] or norm(x["query"]) in norm(h.get("text", ""))]
            res[name] = {"returned": len(hits), "from_other_case": len(bad)}; leaks += len(bad)
        xrows.append({"id": x["id"], "query": x["query"], **res})
    # sanity: the same markers ARE found in their own case (so a clean result is not an empty index)
    own = []
    for x in Q["cross_case"]:
        h = vs.lexical_search(x["query"], B["case_id"], B["qpath"], limit=5)
        own.append({"id": x["id"], "found_in_own_case": bool(h)})
    # mismatched handle: case-A id against case-B storage directory
    try:
        mm = vs.lexical_search(Q["cross_case"][0]["query"], A["case_id"], B["qpath"], limit=5); mm_n = len(mm)
    except Exception as e:
        mm_n = f"raised {type(e).__name__}"
    rep["cross_case"] = {"probes": xrows, "total_chunks_from_other_case": leaks,
                         "markers_found_in_own_case": own, "case_A_id_against_case_B_directory": mm_n}

    # --- abstention (retrieval level): the production lexical gate (rag_engine.query_shares_no_terms).
    # Whole-case = the gate applied to every chunk in the case, i.e. independent of any retriever: if it fires
    # here it fires for every retriever. The cosine-floor gate needs the real embedder and is evaluated only
    # in --embedder real --llm runs via `model_not_consulted`.
    whole_case = []
    _c = vs.get_client(A["qpath"]); _off = None
    while True:
        recs, _off = _c.scroll(vs.get_collection_name(A["case_id"]), limit=512, offset=_off, with_payload=True, with_vectors=False)
        whole_case += [{"text": (x.payload or {}).get("text", "")} for x in recs]
        if _off is None: break
    ab = []
    for u in Q["unanswerable"]:
        hits = vs.lexical_search(u["query"], A["case_id"], A["qpath"], limit=rag.RETRIEVAL_TOP_K)
        ab.append({"id": u["id"], "query": u["query"], "exact_term_hits": len(hits),
                   "gate_fires_on_exact_term_hits": bool(rag.query_shares_no_terms(u["query"], hits)[0]) if hits else True,
                   "gate_fires_on_whole_case": bool(rag.query_shares_no_terms(u["query"], whole_case)[0])})
    rep["abstention_retrieval_level"] = ab

    # --- full pipeline with the local LLM
    if a.llm:
        from backend.dependencies import get_settings
        cases_dir = get_settings().cases_dir
        full, sheet = [], []
        for kind, items in (("answerable", Q["answerable"]), ("unanswerable", Q["unanswerable"])):
            for it in items:
                t = time.perf_counter()
                try:
                    r = rag.run_rag_query(query=it["query"], case_id=A["case_id"], qpath=None, **{}) if False else \
                        rag.run_rag_query(query=it["query"], case_id=A["case_id"], qdrant_path=A["qpath"], cases_dir=cases_dir)
                    err = None
                except Exception as e:
                    r, err = {}, f"{type(e).__name__}: {e}"
                dt = round(time.perf_counter() - t, 2)
                ps = (r.get("prompt_stats") or {})
                full.append({"id": it["id"], "set": kind, "query": it["query"], "seconds": dt, "error": err,
                             "model_not_consulted": ps.get("model_not_consulted"),
                             "refused": r.get("refused"), "grounding": r.get("grounding"),
                             "sources": sorted({c.get("source") for c in (r.get("chunks_used") or [])}),
                             "answer": r.get("answer")})
                sheet.append({"id": it["id"], "set": kind, "query": it["query"], "answer": r.get("answer"),
                              "cited_sources": "; ".join(sorted({c.get("source") for c in (r.get("chunks_used") or [])})),
                              "claim_no": "", "claim_text": "", "label(FULL/PARTIAL/UNSUPPORTED/CONTRADICTED)": "",
                              "supporting_passage": "", "notes": ""})
        rep["full_pipeline"] = full
        rep["llm_model"] = get_settings().ollama_model
        os.makedirs(a.out, exist_ok=True)
        with open(os.path.join(a.out, "claim_judging_sheet.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(sheet[0].keys())); w.writeheader(); w.writerows(sheet)

    os.makedirs(a.out, exist_ok=True)
    tag = {"real": "real", "none": "exact_term_only", "stub": "STUB_plumbing_test"}[a.embedder]
    json.dump(rep, open(os.path.join(a.out, f"results_{tag}.json"), "w"), indent=1, default=str)
    with open(os.path.join(a.out, f"per_query_{tag}.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(json.dumps({k: rep[k] for k in ("embedder_mode", "case_A", "case_B", "retrieval",
                                           "retrieval_latency_ms_median_of_queries")}, indent=1))
    print("cross-case chunks from other case:", leaks)
    print("written to", a.out)


if __name__ == "__main__":
    main()
