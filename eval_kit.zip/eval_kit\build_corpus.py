#!/usr/bin/env python3
"""
Controlled SYNTHETIC test corpus for the IDF-AI Assistant evaluation.

Everything here is invented by the authors for testing. Names, hosts, addresses
(RFC 5737 documentation ranges and .example domains), accounts and hashes are
fictional. This is NOT real investigation data and NOT a public benchmark.

Output (written next to this script):
  corpus/case_A/*.{txt,log,csv}     the case that is queried
  corpus/case_B/*.{txt,log,csv}     a second case with disjoint marker strings
  queries.json                      labelled queries (gold span = relevance label)

Relevance label: a retrieved chunk is RELEVANT to a query iff its text contains the
query's `gold_span` (whitespace-normalised, case-insensitive). The span is chosen to be
<= 100 characters, shorter than the 120-character chunk overlap, so it always lies
entirely inside at least one chunk.
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))

CASE_A = {}
CASE_B = {}

CASE_A["firewall_20250314.log"] = """sensor=fw-edge-01 log=conntrack
2025-03-14T02:11:07Z src=198.51.100.23 dst=10.0.4.19 dport=443 proto=TCP action=ALLOW bytes=184320
2025-03-14T02:13:44Z src=10.0.4.19 dst=203.0.113.77 dport=8443 proto=TCP action=ALLOW bytes=4980736000
2025-03-14T02:41:12Z src=10.0.4.19 dst=203.0.113.77 dport=8443 proto=TCP action=ALLOW bytes=512000
2025-03-14T03:02:01Z src=203.0.113.77 dst=10.0.4.19 dport=22 proto=TCP action=DENY bytes=0
2025-03-14T04:20:19Z src=10.0.4.31 dst=192.0.2.140 dport=53 proto=UDP action=ALLOW bytes=312
2025-03-14T07:55:30Z src=10.0.4.19 dst=10.0.4.5 dport=445 proto=TCP action=ALLOW bytes=2048
2025-03-14T09:12:02Z src=10.0.4.44 dst=198.51.100.200 dport=3389 proto=TCP action=DENY bytes=0
"""

CASE_A["email_thread_blackwell.txt"] = """From: m.blackwell@vortexcorp.example
To: c.rivera@phantomlabs.example
Date: Fri, 14 Mar 2025 06:02:00 +0000
Subject: Re: final batch

Carlos - the overnight job finished clean. We moved 4.7 GB to the darknode.example staging host between 02:13 and 02:45. The archive checksum is 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08. Wipe the local copies once you have confirmed the checksum on your side. Do not route this through the corporate mail relay again.
- Marcus

----- Original Message -----
From: c.rivera@phantomlabs.example
Date: Thu, 13 Mar 2025 21:40:00 +0000
Subject: final batch

Marcus - the payment for the second invoice goes out Friday morning. I will need the files before the Monday audit starts, and I would rather nobody in finance hears about the staging host.
"""

CASE_A["transactions_q1.csv"] = """date,account,amount_usd,beneficiary,reference
2025-03-12,ACC-4471-9930,18500.00,Phantom Labs LLC,INV-8841
2025-03-12,ACC-4471-9930,4200.00,Phantom Labs LLC,INV-8842
2025-03-13,ACC-9012-3310,900.00,Havenport Couriers,INV-8843
2025-03-13,ACC-7720-1184,63250.00,Redwater Consulting,INV-8850
2025-03-15,ACC-9012-3310,1275.50,Havenport Couriers,INV-8851
2025-03-17,ACC-4471-9930,9980.00,Offshore Holdings Ltd,INV-8860
"""

CASE_A["witness_statement_sokolov.txt"] = """Statement of Diana Sokolov, taken 16 March 2025.

On the afternoon of 14 March 2025 I was at the loading bay on Havenport Road. Priya Mehta was present and signed for the delivery. A white van with a Havenport Couriers logo left at about 17:40. I did not see who was driving. Earlier that day I noticed a man in a grey hooded jacket photographing the side door of the warehouse with his phone. He walked away towards the railway bridge when he saw me looking.
"""

CASE_A["chat_export_signal.txt"] = """[2025-03-13 22:14] Carlos R: did you move the drives out of the cabinet
[2025-03-13 22:15] Marcus B: yes they are in the boot of my car, the blue estate
[2025-03-13 22:17] Carlos R: good. the key for the cabinet stays with me until Monday
[2025-03-14 05:49] Marcus B: transfer is done, I deleted the shell history on the jump box
[2025-03-14 05:51] Carlos R: use the burner phone from now on, the number ending 0147
[2025-03-14 11:30] Marcus B: the auditors asked about the Redwater invoice, say it was a retainer
"""

CASE_A["vpn_auth.log"] = """2025-03-13T23:58:11Z vpn-gw-02 user=mblackwell result=SUCCESS src_ip=198.51.100.9 method=password+totp
2025-03-14T00:03:40Z vpn-gw-02 user=crivera result=FAIL src_ip=192.0.2.88 method=password reason=bad_password
2025-03-14T00:04:02Z vpn-gw-02 user=crivera result=FAIL src_ip=192.0.2.88 method=password reason=bad_password
2025-03-14T00:04:30Z vpn-gw-02 user=crivera result=SUCCESS src_ip=192.0.2.88 method=password+totp
2025-03-14T01:30:55Z vpn-gw-02 user=svc_backup result=SUCCESS src_ip=10.0.4.5 method=certificate
2025-03-14T06:15:09Z vpn-gw-02 user=mblackwell result=LOGOUT src_ip=198.51.100.9 session_seconds=22618
"""

CASE_A["usb_device_history.txt"] = """USBSTOR registry export, workstation WS-FIN-07.
Device: SanDisk Ultra USB Device, serial 4C530001230314101352, first connected 2025-03-13 21:55 UTC, last connected 2025-03-14 01:20 UTC.
Device: Kingston DataTraveler 3.0, serial 001CC0EC34D0B031A8F10A4A, first connected 2024-11-02 09:12 UTC, last connected 2024-11-02 09:40 UTC.
The SanDisk device was mounted as drive letter E: and approximately 412 files were copied to it during the last session. No antivirus alerts were raised for either device.
"""

CASE_A["incident_report_it_security.txt"] = """IT Security incident report IR-2025-0314, prepared by Hannah Osei, 17 March 2025.

Summary. Between 02:13 and 02:45 UTC on 14 March 2025 the workstation WS-FIN-07 (10.0.4.19) sent roughly 4.9 GB of outbound traffic to an address that is not on the approved vendor list. The transfer used a non-standard TLS port and completed in under thirty minutes.

Timeline. The user account crivera authenticated to the VPN at 00:04 after two failed attempts. At 01:20 a removable drive was disconnected from WS-FIN-07. The outbound transfer began fifty-three minutes later. At 03:02 the remote host attempted an inbound SSH connection, which the firewall rejected.

Containment. The workstation was isolated from the network at 08:10 and a forensic image was taken at 10:45. The VPN account for crivera was disabled at 08:25 pending interview. Management was informed at 09:00.

Recommendations. Review outbound egress rules for finance workstations, require hardware-token authentication for the VPN, and block removable media on systems that handle payment data.
"""

CASE_A["browser_history_ws_fin_07.csv"] = """timestamp,url,title,visit_count
2025-03-13T21:30:12Z,https://mail.vortexcorp.example/inbox,Inbox,14
2025-03-13T21:47:50Z,https://filetransfer.darknode.example/upload,Secure Upload,3
2025-03-13T22:05:33Z,https://search.example/?q=how+to+wipe+shell+history,how to wipe shell history,1
2025-03-14T01:42:08Z,https://pastebin.example/raw/Zk39Q0aL,Untitled paste,1
2025-03-14T08:20:41Z,https://hr.vortexcorp.example/policies/data-handling,Data Handling Policy,2
"""

CASE_A["hr_memo_data_handling.txt"] = """Vortex Corp - Human Resources memo HR-114. Subject: Data handling and removable media.

Employees must not copy customer or payment records to personal or removable storage. Exceptions require written approval from the Chief Information Security Officer, Dr. Ibrahim Nasser. Breaches of this policy may lead to disciplinary action, including dismissal, and may be reported to law enforcement. All staff completed the annual awareness training in January 2025.
"""

CASE_A["server_inventory.csv"] = """hostname,ip,role,owner,last_patched
srv-db-01,10.0.4.5,database,platform team,2025-02-20
srv-app-03,10.0.4.12,application,platform team,2025-02-20
ws-fin-07,10.0.4.19,finance workstation,C. Rivera,2025-01-30
ws-fin-08,10.0.4.31,finance workstation,L. Tanaka,2025-03-01
jump-01,10.0.4.44,jump host,infrastructure,2025-03-02
"""

CASE_A["dns_queries.log"] = """2025-03-13T21:46:58Z client=10.0.4.19 query=filetransfer.darknode.example type=A answer=203.0.113.77
2025-03-13T21:47:03Z client=10.0.4.19 query=cdn.updates.example type=A answer=192.0.2.15
2025-03-14T04:20:19Z client=10.0.4.31 query=time.pool.example type=A answer=192.0.2.140
2025-03-14T02:12:40Z client=10.0.4.19 query=darknode.example type=TXT answer="v=spf1 -all"
"""

CASE_A["meeting_notes_audit.txt"] = """Audit committee notes, 18 March 2025. Present: Laura Tanaka (finance), Dr. Ibrahim Nasser (CISO), Hannah Osei (IT security), Grace Whitfield (internal audit).

The committee reviewed invoice INV-8850 from Redwater Consulting for 63,250 dollars. Grace Whitfield noted that no statement of work was on file and that the purchase order was raised after the invoice date. Laura Tanaka said the invoice had been approved verbally by Marcus Blackwell. The committee agreed to freeze further payments to Redwater Consulting until documentation is produced.
"""


# ---------------- Seeded filler (background volume) ----------------
# Deterministic (random.Random(2025)) benign records so that the case is large enough for Recall@k to be
# non-trivial. None of it contains a gold span or an identifier used as an identifier query (asserted in main()).
import random
_R = random.Random(2025)
_RESERVED = {"203.0.113.77", "198.51.100.23", "198.51.100.9", "198.51.100.200", "192.0.2.88", "192.0.2.140"}  # appear in hand-written files
def _ip(pool):
    while True:
        ip = _R.choice(pool) + str(_R.randint(1, 250))
        if ip not in _RESERVED:
            return ip
_INT = ["10.0.%d." % n for n in (1, 2, 3, 6, 7, 8)]
_EXT = ["198.51.100.", "192.0.2.", "203.0.113."]
def _fw(day, n):
    out = ["sensor=fw-edge-01 log=conntrack"]
    for i in range(n):
        h, m, s_ = _R.randint(0, 23), _R.randint(0, 59), _R.randint(0, 59)
        src, dst = (_ip(_INT), _ip(_EXT)) if _R.random() < .6 else (_ip(_EXT), _ip(_INT))
        out.append(f"{day}T{h:02d}:{m:02d}:{s_:02d}Z src={src} dst={dst} dport={_R.choice([80,443,443,443,53,123,993,587])} "
                   f"proto={_R.choice(['TCP','TCP','UDP'])} action={_R.choice(['ALLOW','ALLOW','ALLOW','DENY'])} bytes={_R.randint(40,90000)}")
    return "\n".join(out) + "\n"
for day, tag in (("2025-03-10","0310"),("2025-03-11","0311"),("2025-03-12","0312"),("2025-03-15","0315"),("2025-03-16","0316")):
    CASE_A[f"firewall_{tag}.log"] = _fw(day, 220)
_DOM = ["update.vendor.example","cdn.assets.example","time.pool.example","mail.vortexcorp.example","intranet.vortexcorp.example",
        "repo.tools.example","telemetry.agent.example","login.saas.example","files.shared.example","ocsp.certs.example"]
def _dns(day, n):
    return "".join(f"{day}T{_R.randint(0,23):02d}:{_R.randint(0,59):02d}:{_R.randint(0,59):02d}Z client={_ip(_INT)} "
                   f"query={_R.choice(_DOM)} type=A answer={_ip(_EXT)}\n" for _ in range(n))
for day, tag in (("2025-03-11","0311"),("2025-03-12","0312"),("2025-03-15","0315")):
    CASE_A[f"dns_queries_{tag}.log"] = _dns(day, 220)
_BEN = ["Northgate Supplies","Brightline Catering","Orchard Facilities","Summit Print Works","Clearwater Cleaning","Kestrel IT Leasing","Maple Stationery","Harbor Insurance Group"]
def _tx(n, start):
    rows = ["date,account,amount_usd,beneficiary,reference"]
    for i in range(n):
        rows.append(f"2025-03-{_R.randint(1,31):02d},ACC-{_R.randint(1000,3999)}-{_R.randint(1000,9999)},{_R.randint(50,9000)}.{_R.randint(0,99):02d},{_R.choice(_BEN)},INV-{start+i}")
    return "\n".join(rows) + "\n"
CASE_A["transactions_archive_a.csv"] = _tx(120, 7000)
CASE_A["transactions_archive_b.csv"] = _tx(120, 7500)
def _vpn(n):
    users = ["akumar","jlee","mpatel","sgomez","tnguyen","rfischer","lhall","dosei2"]
    return "".join(f"2025-03-{_R.randint(10,16):02d}T{_R.randint(0,23):02d}:{_R.randint(0,59):02d}:{_R.randint(0,59):02d}Z vpn-gw-02 "
                   f"user={_R.choice(users)} result={_R.choice(['SUCCESS','SUCCESS','SUCCESS','LOGOUT'])} src_ip={_ip(_EXT)} method=password+totp\n" for _ in range(n))
CASE_A["vpn_auth_archive.log"] = _vpn(260)
_TOPICS = [
 ("Facilities notice","The east stairwell will be closed for repainting from Monday to Wednesday. Staff should use the lifts or the west stairwell. Contractors will be signed in at reception and escorted at all times."),
 ("Travel policy reminder","Economy fares must be booked at least fourteen days ahead. Hotel stays are capped at the published city rate. Receipts are required for any claim above twenty-five dollars."),
 ("Canteen menu","Soup of the day is leek and potato. The vegetarian main is a roasted vegetable tart. Hot drinks are free before nine o'clock."),
 ("Parking update","Visitor spaces in the north car park are reserved for clients. Permit holders should display their permit on the dashboard. Cycle racks have been added beside the loading dock."),
 ("IT maintenance window","Routine patching of the print servers will take place on Sunday between 01:00 and 03:00. Printing may be unavailable during this time. No action is needed from staff."),
 ("Training schedule","The first-aid refresher course runs in the training room next month. Places are limited to twelve. Managers should confirm attendance with the facilities team."),
 ("Newsletter","The sales team exceeded its quarterly target and the new customer portal entered beta testing. Thanks to everyone who volunteered for the charity fun run."),
 ("Procurement note","Quotes from three suppliers are required for purchases over five thousand dollars. Framework agreements are listed on the intranet. Exceptions must be approved by the head of procurement."),
 ("Security awareness tip","Be cautious of unexpected attachments and links in e-mail. Report anything suspicious using the report button in your mail client. Never share passwords, even with colleagues."),
 ("Recycling reminder","Paper, glass and plastics have separate bins on each floor. Batteries and small electronics should be handed to the facilities desk for safe disposal."),
 ("Visitor policy","All visitors must sign in and wear a badge. Badges are collected at reception when the visitor leaves. Escorts are responsible for visitors in restricted areas."),
 ("Holiday rota","Annual leave requests for the summer period should be submitted by the end of April. Managers will confirm cover arrangements before approval."),
]
for i, (t, body) in enumerate(_TOPICS, 1):
    CASE_A[f"notice_{i:02d}.txt"] = f"{t}. Reference NTC-{200+i}.\n\n{body}\n"

# ---------------- Case B (second case, disjoint markers) ----------------
CASE_B["maintenance_log_lantern.txt"] = """Lantern Freight maintenance log. Vehicle LF-2291 serviced at Eastgate Depot on 2 June 2025 by technician Omar Haddad. Brake pads replaced, odometer 184,220 km. Marker string for this case: LANTERN-ZX-5518."""
CASE_B["driver_roster_lantern.csv"] = """driver,vehicle,shift_start,badge
Amara Obi,LF-2291,05:30,BDG-77310
Tomasz Wrona,LF-1840,06:00,BDG-77415
"""
CASE_B["gps_events_lantern.log"] = """2025-06-02T06:14:09Z vehicle=LF-2291 lat=51.5074 lon=-0.1278 speed_kph=0 event=ignition_on
2025-06-02T06:52:31Z vehicle=LF-2291 lat=51.4545 lon=-2.5879 speed_kph=87 event=cruise
2025-06-02T08:03:48Z vehicle=LF-1840 lat=52.4862 lon=-1.8904 speed_kph=0 event=door_open note=unscheduled_stop_cabinet_ref_QX-4029
"""
CASE_B["customer_complaint_lantern.txt"] = """Complaint 2025-0611 from Brightwater Pharmacy about a delayed consignment. The courier said the vehicle was held up at the Ashford checkpoint. Customer reference BWP-90417. The consignment contained temperature-controlled insulin."""

ALT = {   # other passages that legitimately contain the identifier (declared in the paper, reported as 'lenient' relevance)
 "Q01": ["query=filetransfer.darknode.example type=A answer=203.0.113.77"],
 "Q05": ["invoice INV-8850 from Redwater Consulting for 63,250 dollars"],
 "Q08": ["https://filetransfer.darknode.example/upload"],
}
def norm(s): return re.sub(r"\s+"," ",s).strip().lower()

# (id, kind, query, file, gold_span)
# kind: identifier = exact string; semantic = paraphrase with little vocabulary overlap
Q = [
 ("Q01","identifier","203.0.113.77","firewall_20250314.log","dst=203.0.113.77 dport=8443 proto=TCP action=ALLOW bytes=4980736000"),
 ("Q02","identifier","9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08","email_thread_blackwell.txt","9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"),
 ("Q03","identifier","ACC-4471-9930","transactions_q1.csv","2025-03-12,ACC-4471-9930,18500.00,Phantom Labs LLC,INV-8841"),
 ("Q04","identifier","4C530001230314101352","usb_device_history.txt","serial 4C530001230314101352"),
 ("Q05","identifier","INV-8850","transactions_q1.csv","ACC-7720-1184,63250.00,Redwater Consulting,INV-8850"),
 ("Q06","identifier","IR-2025-0314","incident_report_it_security.txt","IR-2025-0314, prepared by Hannah Osei"),
 ("Q07","identifier","svc_backup","vpn_auth.log","user=svc_backup result=SUCCESS src_ip=10.0.4.5"),
 ("Q08","identifier","filetransfer.darknode.example","dns_queries.log","query=filetransfer.darknode.example type=A answer=203.0.113.77"),
 ("Q09","identifier","pastebin.example/raw/Zk39Q0aL","browser_history_ws_fin_07.csv","https://pastebin.example/raw/Zk39Q0aL"),
 ("Q10","identifier","ws-fin-08","server_inventory.csv","ws-fin-08,10.0.4.31,finance workstation,L. Tanaka"),
 ("Q11","identifier","number ending 0147","chat_export_signal.txt","the number ending 0147"),
 ("Q12","identifier","HR-114","hr_memo_data_handling.txt","memo HR-114"),
 ("Q13","semantic","How much data left the finance workstation for the unfamiliar external host and through which port?","firewall_20250314.log","dst=203.0.113.77 dport=8443 proto=TCP action=ALLOW bytes=4980736000"),
 ("Q14","semantic","Who was told to delete the copies after the checksum was verified?","email_thread_blackwell.txt","Wipe the local copies once you have confirmed the checksum"),
 ("Q15","semantic","Which payment went to the consultancy that had no contract on file?","meeting_notes_audit.txt","invoice INV-8850 from Redwater Consulting for 63,250 dollars"),
 ("Q16","semantic","Where did the suspect keep the physical drives overnight?","chat_export_signal.txt","they are in the boot of my car, the blue estate"),
 ("Q17","semantic","Which person saw someone taking pictures of the building entrance?","witness_statement_sokolov.txt","a man in a grey hooded jacket photographing the side door of the warehouse"),
 ("Q18","semantic","When was the infected workstation cut off from the network and when was it imaged?","incident_report_it_security.txt","isolated from the network at 08:10 and a forensic image was taken at 10:45"),
 ("Q19","semantic","How many files were put on the removable storage during the last session?","usb_device_history.txt","approximately 412 files were copied to it during the last session"),
 ("Q20","semantic","Did anyone try to log in with the wrong password before getting in?","vpn_auth.log","user=crivera result=FAIL src_ip=192.0.2.88 method=password reason=bad_password"),
 ("Q21","semantic","Who is allowed to approve copying customer records onto personal media?","hr_memo_data_handling.txt","written approval from the Chief Information Security Officer, Dr. Ibrahim Nasser"),
 ("Q22","semantic","What did the suspect search for online shortly before the transfer?","browser_history_ws_fin_07.csv","how to wipe shell history"),
 ("Q23","semantic","Which payments were sent to the courier company?","transactions_q1.csv","2025-03-13,ACC-9012-3310,900.00,Havenport Couriers,INV-8843"),
 ("Q24","semantic","What remedial steps did security recommend for finance computers?","incident_report_it_security.txt","block removable media on systems that handle payment data"),
 ("Q25","semantic","What decision did the committee take about further payments to the consultancy?","meeting_notes_audit.txt","freeze further payments to Redwater Consulting until documentation is produced"),
 ("Q26","semantic","How should the invoice be explained if the auditors ask?","chat_export_signal.txt","say it was a retainer"),
 ("Q27","semantic","Which delivery vehicle left the loading bay in the evening and what was on its side?","witness_statement_sokolov.txt","A white van with a Havenport Couriers logo left at about 17:40"),
 ("Q28","semantic","Which account paid a company that appears to be registered abroad?","transactions_q1.csv","ACC-4471-9930,9980.00,Offshore Holdings Ltd,INV-8860"),
 ("Q29","semantic","Who owns the machine that the data was taken from?","server_inventory.csv","ws-fin-07,10.0.4.19,finance workstation,C. Rivera"),
 ("Q30","semantic","Was an inbound connection from the remote host permitted?","firewall_20250314.log","dst=10.0.4.19 dport=22 proto=TCP action=DENY"),
]
# Unanswerable (question about something NOT in case A) -> system should abstain
U = [
 ("U01","What is the capital of Finland?"),
 ("U02","Which ransomware family encrypted the file server?"),
 ("U03","What was the suspect's salary in 2024?"),
 ("U04","List the passengers on the flight to Dubai."),
 ("U05","Which cryptocurrency wallet received the ransom payment?"),
 ("U06","What medication was prescribed to the witness?"),
 ("U07","At what time did the fire alarm sound in the warehouse?"),
 ("U08","Who is the CEO of Brightwater Pharmacy?"),
]
# Cross-case probes: marker strings that exist ONLY in case B, asked against case A
X = [
 ("X01","LANTERN-ZX-5518","maintenance_log_lantern.txt"),
 ("X02","BDG-77310","driver_roster_lantern.csv"),
 ("X03","QX-4029","gps_events_lantern.log"),
 ("X04","BWP-90417","customer_complaint_lantern.txt"),
 ("X05","Eastgate Depot brake pads LF-2291","maintenance_log_lantern.txt"),
]

def main():
    for sub,files in (("case_A",CASE_A),("case_B",CASE_B)):
        d=os.path.join(HERE,"corpus",sub); os.makedirs(d,exist_ok=True)
        for fn,txt in files.items():
            with open(os.path.join(d,fn),"w",encoding="utf-8",newline="\n") as f: f.write(txt)
    # self-check: every gold span must occur in its file
    bad=[q[0] for q in Q if norm(q[4]) not in norm(CASE_A[q[3]])]
    if bad: sys.exit("gold span missing from file for: "+", ".join(bad))
    # gold spans must occur only in the file they are attributed to, and identifier queries only where intended
    allA = {fn: norm(t) for fn, t in CASE_A.items()}
    for q in Q:
        where = [fn for fn, t in allA.items() if norm(q[4]) in t]
        assert where == [q[3]], f"gold span of {q[0]} found in {where}"
    intended = {"Q01":{"firewall_20250314.log","dns_queries.log"},"Q05":{"transactions_q1.csv","meeting_notes_audit.txt"},
                "Q08":{"dns_queries.log","browser_history_ws_fin_07.csv"}}
    for q in Q:
        if q[1] == "identifier" and q[0] != "Q11":
            where = {fn for fn, t in allA.items() if norm(q[2]) in t}
            ok = intended.get(q[0], {q[3]})
            assert where <= ok | {q[3]}, f"identifier {q[2]} found in unintended files {where - ok}"
    for qid,mark,fn in X:
        assert norm(mark.split(" ")[0]) in norm(CASE_B[fn]) or qid=="X05"
        assert not any(norm(mark) in norm(t) for t in CASE_A.values()), "marker leaked into case A: "+qid
    out={
     "note":"Controlled synthetic data created by the authors; not real casework, not a public benchmark.",
     "answerable":[{"id":a,"kind":k,"query":q,"gold_file":f,"gold_span":s,"alt_spans":ALT.get(a,[])} for a,k,q,f,s in Q],
     "unanswerable":[{"id":a,"query":q} for a,q in U],
     "cross_case":[{"id":a,"query":q,"lives_in_case_B_file":f} for a,q,f in X],
    }
    json.dump(out,open(os.path.join(HERE,"queries.json"),"w"),indent=1,ensure_ascii=False)
    print("case A files:",len(CASE_A),"case B files:",len(CASE_B),
          "answerable:",len(Q),"unanswerable:",len(U),"cross-case:",len(X))
if __name__=="__main__": main()
