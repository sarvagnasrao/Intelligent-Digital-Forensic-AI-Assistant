@echo off
setlocal
set PYTHONUTF8=1
set "HERE=%~dp0"
set "REPO=%HERE%.."
set "PY=%USERPROFILE%\venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
echo Using Python: %PY%
echo.
echo Before continuing: stop the backend and Vite, and make sure Ollama is running
echo with the model pulled (ollama pull llama3.2:3b).
pause
cd /d "%HERE%"
"%PY%" build_corpus.py || goto :err
"%PY%" run_eval.py --repo "%REPO%" --embedder real --llm --out "%HERE%results_full" || goto :err
echo.
echo DONE. Results are in %HERE%results_full
pause
exit /b 0
:err
echo FAILED. Copy the error text above and send it back.
pause
exit /b 1
