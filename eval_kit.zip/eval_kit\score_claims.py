#!/usr/bin/env python3
"""Compute claim-support and abstention figures from the filled-in claim_judging_sheet.csv.

Fill the sheet as follows (one row per atomic factual claim in an answer; add rows as needed):
  answerable questions : label = FULL | PARTIAL | UNSUPPORTED | CONTRADICTED
                         judged against the excerpts the system retrieved for that answer
                         (the answer's source footer + results JSON `sources`), not against your own knowledge.
  unanswerable questions: one row per question; label = ABSTAIN (the answer says the evidence does not
                         establish it, or the model was not consulted) | ANSWERED (it gave a substantive answer).
"""
import csv, sys, collections
path = sys.argv[1] if len(sys.argv) > 1 else "results/claim_judging_sheet.csv"
col = "label(FULL/PARTIAL/UNSUPPORTED/CONTRADICTED)"
rows = list(csv.DictReader(open(path, encoding="utf-8")))
ans = collections.Counter(r[col].strip().upper() for r in rows if r["set"] == "answerable" and r[col].strip())
tot = sum(ans.values())
print(f"Answerable-question claims judged: {tot}")
for k in ("FULL", "PARTIAL", "UNSUPPORTED", "CONTRADICTED"):
    print(f"  {k:13s} {ans[k]:4d}  ({ans[k]}/{tot} = {100*ans[k]/tot:.1f}%)" if tot else f"  {k} 0")
if tot:
    print(f"Claim-support rate (FULL only)          = {ans['FULL']}/{tot} = {100*ans['FULL']/tot:.1f}%")
    print(f"Claim-support rate (FULL + PARTIAL)     = {ans['FULL']+ans['PARTIAL']}/{tot} = {100*(ans['FULL']+ans['PARTIAL'])/tot:.1f}%")
un = collections.Counter(r[col].strip().upper() for r in rows if r["set"] == "unanswerable" and r[col].strip())
n = sum(un.values())
if n:
    print(f"Abstention on unanswerable questions     = {un['ABSTAIN']}/{n} = {100*un['ABSTAIN']/n:.1f}%")
