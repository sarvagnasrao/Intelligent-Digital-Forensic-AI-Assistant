# Evaluation kit — Intelligent Digital Forensic AI Assistant

Controlled **synthetic** test data (invented by the authors; not real casework, not a public benchmark).

| File | Purpose |
|---|---|
| `build_corpus.py` | Regenerates `corpus/case_A` (36 files, 393 chunks), `corpus/case_B` (4 files) and `queries.json` deterministically; self-checks that every gold span and identifier occurs only where intended. |
| `queries.json` | 30 answerable queries (12 identifier, 18 paraphrase) with gold span (+ alternative spans), 8 unanswerable queries, 5 cross-case probes. |
| `run_eval.py` | Indexes both cases into an **isolated temporary** Qdrant store using the project's own `chunk_text` and `store_chunks`, then evaluates the project's own retrievers. |
| `score_claims.py` | Computes claim-support and abstention rates from the judging sheet. |
| `results/` | Outputs. `results_exact_term_only.json` was produced by the authors' tooling in a sandbox (no embedding model, no LLM). |

## Run on the project machine (the full evaluation)

```bash
# 1. the project's own environment must be installed (torch + sentence-transformers, spaCy model, ...)
# 2. stop the backend and Vite (they share data/forensic.db and the Qdrant lock)
# 3. start Ollama and pull the model:  ollama serve ;  ollama pull llama3.2:3b
python run_eval.py --repo /path/to/Intelligent-Digital-Forensic-AI-Assistant --embedder real --llm --out results_full
python score_claims.py results_full/claim_judging_sheet.csv      # after filling the sheet by hand
```
`--embedder none` needs no models and evaluates the exact-term retriever only. `--embedder stub` is a plumbing
test whose numbers are meaningless (its output files are labelled STUB).

## Definitions
* Relevant chunk: contains the query's gold span (or an alternative span) after whitespace/case normalisation.
* Recall@k: queries with a relevant chunk in the top k, divided by the number of answerable queries
  (one relevant passage per query, so this equals hit-rate@k). MRR: mean of 1/rank (0 if absent in the top 14).
* "Strict" counts the gold span only; the default ("lenient") also accepts the declared alternative spans
  (three identifier queries whose identifier legitimately appears in a second file).
* Claim support: split each answer into atomic factual claims; judge each against the excerpts that were
  retrieved for that answer: FULL / PARTIAL / UNSUPPORTED / CONTRADICTED. The judge should not see which
  retriever produced the excerpts, and a second person should label at least a sample to report agreement.
